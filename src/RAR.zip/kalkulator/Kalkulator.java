/*
 * Copyright Riyan Jaya Adi Pratama
 * 
 * 
 */
package kalkulator;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTextField;



import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

public class Kalkulator {

	private JFrame frame;
	private JFrame frame_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Kalkulator window = new Kalkulator();
					window.frame_1.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Kalkulator() {
		initialize();
	}

	private final JButton buttonnum2 = new JButton("2");
	private final JButton buttonnum3 = new JButton("3");
	private final JButton buttonnum6 = new JButton("6");
	private final JButton buttonnum5 = new JButton("5");
	private final JButton buttonnum4 = new JButton("4");
	private final JButton buttonnum9 = new JButton("9");
	private final JButton buttonnum8 = new JButton("8");
	private final JButton buttonnum7 = new JButton("7");
	private final JButton buttonnum0 = new JButton("0");
	private final JButton buttonclear = new JButton("C");
	private final JButton buttonclearentry = new JButton("CE");
	private final JButton buttonback = new JButton("BACK");
	private final JButton buttonequal = new JButton("=");
	private final JTextField textField1 = new JTextField();
	private final JTextField textField2 = new JTextField();
	private final JTextField textans = new JTextField();
	private final JButton buttonbagi = new JButton("/");
	private final JButton buttonkali = new JButton("*");
	private final JButton buttontambah = new JButton("+");
	private final JButton buttonkurang = new JButton("-");

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame_1 = new JFrame();
		frame_1.getContentPane().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		frame_1.getContentPane().setBackground(SystemColor.inactiveCaptionBorder);
		frame_1.setBounds(100, 100, 282, 397);
		frame_1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_1.getContentPane().setLayout(null);
		
		JButton buttonnum1 = new JButton("1");
		buttonnum1.setBounds(10, 248, 50, 50);
		buttonnum1.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
				
			}
		});
		buttonnum0.setBounds(10, 298, 148, 50);
		buttonnum0.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

			}
		});
		
		frame_1.getContentPane().add(buttonnum0);
		frame_1.getContentPane().add(buttonnum1);
		buttonnum2.setBounds(59, 248, 50, 50);
		buttonnum2.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum2);
		buttonnum3.setBounds(108, 248, 50, 50);
		buttonnum3.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum3);
		buttonnum4.setBounds(10, 199, 50, 50);
		buttonnum4.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum4);
		buttonnum6.setBounds(108, 199, 50, 50);
		buttonnum6.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		buttonnum5.setBounds(59, 199, 50, 50);
		buttonnum5.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum5);
		
		frame_1.getContentPane().add(buttonnum6);
		buttonnum7.setBounds(10, 150, 50, 50);
		buttonnum7.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum7);
		buttonnum8.setBounds(59, 150, 50, 50);
		buttonnum8.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum8);
		buttonnum9.setBounds(108, 150, 50, 50);
		buttonnum9.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame_1.getContentPane().add(buttonnum9);
		buttonback.setBounds(10, 101, 99, 50);
		buttonback.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {				
			}
		});
		buttonback.setBackground(SystemColor.window);
		buttonback.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame_1.getContentPane().add(buttonback);
		buttonclearentry.setBounds(108, 101, 50, 50);
		buttonclearentry.setBackground(SystemColor.window);
		buttonclearentry.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame_1.getContentPane().add(buttonclearentry);
		buttonclear.setBounds(157, 101, 50, 50);
		buttonclear.setBackground(SystemColor.window);
		buttonclear.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame_1.getContentPane().add(buttonclear);
		buttonequal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e){ 
				
			}
		});
		
		buttonbagi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double num1, num2, ans;
				try {
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					
					
					ans=num1/num2;
					textans.setText(Double.toString(ans));	
				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
		});
		buttonbagi.setBounds(157, 150, 50, 50);
		frame_1.getContentPane().add(buttonbagi);
		
		buttonkali.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double num1, num2, ans;
				try {
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					
					
					ans=num1*num2;
					textans.setText(Double.toString(ans));	
				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
		});
		buttonkali.setBounds(157, 199, 50, 50);
		frame_1.getContentPane().add(buttonkali);
		
		buttontambah.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double num1, num2, ans;
				try {
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					
					
					ans=num1+num2;
					textans.setText(Double.toString(ans));	
				} catch (Exception e2) {
					// TODO: handle exception
				}
					
			}
		});
		buttontambah.setBounds(157, 248, 50, 50);
		frame_1.getContentPane().add(buttontambah);
		
		buttonkurang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double num1, num2, ans;
				try {
					num1=Integer.parseInt(textField1.getText());
					num2=Integer.parseInt(textField2.getText());
					
					
					ans=num1-num2;
					textans.setText(Double.toString(ans));	
				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
		});
		buttonkurang.setBounds(157, 298, 50, 50);
		frame_1.getContentPane().add(buttonkurang);
		buttonequal.setBounds(206, 101, 50, 247);
		buttonequal.setBackground(SystemColor.window);
		buttonequal.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame_1.getContentPane().add(buttonequal);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 97, 21);
		frame_1.getContentPane().add(menuBar);
		
		JMenu MenuHelp = new JMenu("Help");
		menuBar.add(MenuHelp);
		
		JMenuItem SubMenuHelp = new JMenuItem("About");
		SubMenuHelp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				System.exit(0);
			}
		});
		MenuHelp.add(SubMenuHelp);
		textField1.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				// TODO Auto-generated method stub
				
			}
		});
		textField1.setBounds(10, 21, 148, 29);
		textField1.setColumns(10);
		
		frame_1.getContentPane().add(textField1);
		textField2.setColumns(10);
		textField2.setBounds(168, 21, 86, 29);
		
		frame_1.getContentPane().add(textField2);
		textans.setColumns(10);
		textans.setBounds(10, 61, 246, 29);
		frame_1.getContentPane().add(textans);
		

	}
	
//Rumus.Hitung
public class DecToBin
{ 
	public void main(String[] args)
		{  	
        Scanner sc = new Scanner(System.in);
        System.out.println("Java Program to Convert Decimal Number to Binary Number");
        	
        int decimalNumber = getInt(sc, "Enter number in decimal: ");
        if (decimalNumber < 0)
        {
            System.out.println("Invalid Input, Please Enter a Positive Number");
            System.exit(0);
        }
        int base = 2; // Base of Binary Number is 2
        System.out.printf("binary = %s n", decimalToBinary(decimalNumber, base));
    }
 
    private String decimalToBinary(int num, int base)
    {
        if (num > 0)
        {
            if (num % base == 0)
            {
                return decimalToBinary(num / base, base) + "0";
            } else
            {
                return decimalToBinary(num / base, base) + "1";
            }
        } else
        {
            return "";
        }
    }
    public int getInt(Scanner sc, String prompt)
    {
       	int integer = 0;
       	boolean isValid = false;
       	while (isValid == false)
       	{
            System.out.print(prompt);
            if (sc.hasNextInt())
            {
                integer = sc.nextInt();
                isValid = true;
            }
            	else
            {
                System.err.println("Error! Invalid number. Try again.");
            }
            sc.nextLine();
        	}
        return integer;
    	}
    }
public void actionPerformed(ActionEvent e)
{
	int num1, num2, ans;
}
}