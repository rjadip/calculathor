package calculator;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;


public class test {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					test window = new test();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	JLabel lblNewLabel = new JLabel("New label");
	JLabel lblNewLabel_1 = new JLabel("New label");
	JLabel lblNewLabel_2 = new JLabel("New label");
	
	
	private JTextField textField;
	private final JLabel lblNewLabel_3 = new JLabel("New label");

	public test() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		lblNewLabel.setBounds(25, 107, 102, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				lblNewLabel.setText("NEENN");
				lblNewLabel_3.setText(textField.getText());
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				lblNewLabel_1.setText("NANN");
				lblNewLabel_2.setText("New Label");
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblNewLabel_2.setText("NIINN");
				lblNewLabel_1.setText("New Label");
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(180, 103, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		
		lblNewLabel_1.setBounds(65, 185, 221, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		lblNewLabel_2.setBounds(109, 31, 160, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(148, 182, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		lblNewLabel_3.setBounds(25, 46, 151, 14);
		
		frame.getContentPane().add(lblNewLabel_3);
	}
}
