/*
 * Copyright
 * 
 */


package calculator;

import java.util.Scanner;

public class DecToBin{ 
    public static void main(String[] args) {
 
        Scanner sc = new Scanner(System.in);
        System.out.println("Java Program to Convert Decimal Number to Binary Number");
        	
        int decimalNumber = getInt(sc, "Enter number in decimal: ");
        if (decimalNumber < 0) {
            System.out.println("Invalid Input, Please Enter a Positive Number");
            System.exit(0);
        }
        int base = 2; // Base of Binary Number is 2
        System.out.printf("binary = %s", decimalToBinary(decimalNumber, base));
    }
 
    private static String decimalToBinary(int dec, int base) {
        if (dec > 0) {
            if (dec % base == 0) {
                return decimalToBinary(dec / base, base) + "0";
            } else {
                return decimalToBinary(dec / base, base) + "1";
            }
        } else {
            return "" ;
        }
    }
 
    public static int getInt(Scanner sc, String prompt) {
        int integer = 0;
        boolean isValid = false;
        while (isValid == false) {
            System.out.print(prompt);
            if (sc.hasNextInt()) {
                integer = sc.nextInt();
                isValid = true;
            } else {
                System.err.println("Error! Invalid number. Try again.");
            }
            sc.nextLine();
        }
        return integer;
    }
}