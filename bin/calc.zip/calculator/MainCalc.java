package calculator;

public class MainCalc extends CalculatorInterface
{

public static void main (String[] args){
	
	CalculatorInterface n = new CalculatorInterface();
	

	}
}
