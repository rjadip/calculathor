package calculator;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Dialog.ModalExclusionType;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CalculatorInterface {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CalculatorInterface window = new CalculatorInterface();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CalculatorInterface() {
		initialize();
	}
	private final JButton buttonnum2 = new JButton("2");
	private final JButton buttonnum3 = new JButton("3");
	private final JButton buttonnum6 = new JButton("6");
	private final JButton buttonnum5 = new JButton("5");
	private final JButton buttonnum4 = new JButton("4");
	private final JButton buttonnum9 = new JButton("9");
	private final JButton buttonnum8 = new JButton("8");
	private final JButton buttonnum7 = new JButton("7");
	private final JButton buttonnum0 = new JButton("0");
	private final JButton buttonclear = new JButton("C");
	private final JButton buttonclearentry = new JButton("CE");
	private final JButton buttonback = new JButton("BACK");
	private final JButton buttonequal = new JButton("=");
	private final JTextField textField = new JTextField();
	private final JTextField textField_1 = new JTextField();
	
	private void initialize() {
		textField_1.setBounds(10, 61, 197, 29);
		textField_1.setColumns(10);
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		textField.setBounds(10, 11, 197, 29);
		textField.setColumns(10);
		frame = new JFrame();
		frame.getContentPane().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		frame.getContentPane().setBackground(SystemColor.inactiveCaptionBorder);
		frame.setBounds(100, 100, 230, 397);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton buttonnum1 = new JButton("1");
		buttonnum1.setBounds(10, 248, 50, 50);
		buttonnum1.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
			}
		});
		buttonnum0.setBounds(10, 298, 148, 50);
		buttonnum0.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum0.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

			}
		});
		
		frame.getContentPane().add(buttonnum0);
		frame.getContentPane().add(buttonnum1);
		buttonnum2.setBounds(59, 248, 50, 50);
		buttonnum2.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum2);
		buttonnum3.setBounds(108, 248, 50, 50);
		buttonnum3.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum3);
		buttonnum6.setBounds(108, 199, 50, 50);
		buttonnum6.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum6);
		buttonnum5.setBounds(59, 199, 50, 50);
		buttonnum5.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum5);
		buttonnum4.setBounds(10, 199, 50, 50);
		buttonnum4.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum4);
		buttonnum9.setBounds(108, 150, 50, 50);
		buttonnum9.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum9);
		buttonnum8.setBounds(59, 150, 50, 50);
		buttonnum8.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum8);
		buttonnum7.setBounds(10, 150, 50, 50);
		buttonnum7.setFont(new Font("Dialog", Font.PLAIN, 12));
		buttonnum7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		
		frame.getContentPane().add(buttonnum7);
		buttonclear.setBounds(157, 101, 50, 50);
		buttonclear.setBackground(SystemColor.window);
		buttonclear.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame.getContentPane().add(buttonclear);
		buttonclearentry.setBounds(108, 101, 50, 50);
		buttonclearentry.setBackground(SystemColor.window);
		buttonclearentry.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame.getContentPane().add(buttonclearentry);
		buttonback.setBounds(10, 101, 99, 50);
		buttonback.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {				
			}
		});
		buttonback.setBackground(SystemColor.window);
		buttonback.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame.getContentPane().add(buttonback);
		buttonequal.setBounds(157, 150, 50, 198);
		buttonequal.setBackground(SystemColor.window);
		buttonequal.setFont(new Font("Dialog", Font.PLAIN, 12));
		
		frame.getContentPane().add(buttonequal);
		
		frame.getContentPane().add(textField);
		
		frame.getContentPane().add(textField_1);
		
	}
}
